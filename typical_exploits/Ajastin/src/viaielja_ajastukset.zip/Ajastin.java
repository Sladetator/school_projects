

/*
 * luokka erilaisten yht�suuruusvertailujen vertailuun niiden viem�n ajan suhteen
 */
public class Ajastin {
    
    //palauttaa kahden merkkijonon vertailuun equals()-metodilla kuluvan ajan, kun verrataan yhden kerran
    public static long onkoSamaEquals(String eka, String toka) {
        long startTime = System.nanoTime();
            eka.equals(toka);
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;
        return elapsedTime;
    }
    
    
    //palauttaa kahden merkkijonon vertailuun  equals()-metodilla kuluvan ajan int.max_valuen verran ajettavien vertailujen j�lkeen
    public static long testaaAika(String eka, String toka) {
        long startTime = System.nanoTime();
        for(int i=0; i < Integer.MAX_VALUE; i++){
            eka.equals(toka);
        }
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println(elapsedTime );
        return elapsedTime; 
    }
 

//ohjelma joka testaa eri metodien merkkijonojen vertailussa viem�� aikaa
public static void main(String[] args) {
    final String eka = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" ;
    final String toka = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" ;
    final String kolmas = "dddddddddddddddddddddddddddddddddddddddddddddddddd" ;
    final String neljas = "dddddddddddddddddddddddddhhddddddddddddddddddddddd" ;
    

    long sailo1 = onkoSamaEquals(eka, toka);
    long sailo2 = onkoSamaEquals(kolmas, neljas);
    long sailo3 = onkoSamaEquals(eka, toka);
    long sailo4 = onkoSamaEquals(eka, neljas);
    System.out.println(eka + " vastaan " + toka  + "\naikaa kului :" + sailo1); //tarkistus true
    System.out.println(kolmas + " vastaan " + neljas + "\naikaa kului :" + sailo2);
    System.out.println(eka + " vastaan " + toka + "\naikaa kului :" + sailo3); //tarkistus true
    System.out.println(kolmas + " vastaan " + neljas + "\naikaa kului :" + sailo4);
    //ajellaan aikatestit muutaman kerran ett� saadaan useampia tuloksia
   System.out.println("ensimm�inen ajo, j�rjestyksess� false-true vuorotellen");
    testaaAika(kolmas,neljas);
    testaaAika(eka,toka);
    testaaAika(kolmas,neljas);
    testaaAika(eka,toka);
    testaaAika(kolmas,neljas);
    testaaAika(eka,toka);
    testaaAika(kolmas,neljas);

    System.out.println("testataan ajokertojen keskiarvoilla");
    //testataan keskiarvojen kautta
   long[] aikaArray = {0,0,0,0};
    long[] aikaArray2 = {0,0,0,0};
    aikaArray[0] = (testaaAika(kolmas,neljas));
    aikaArray[1] = (testaaAika(kolmas,neljas));
    aikaArray[2] = (testaaAika(kolmas,neljas));
    aikaArray[3] = (testaaAika(kolmas,neljas));
    aikaArray2[0] = (testaaAika(eka,toka));
    aikaArray2[1] = (testaaAika(eka,toka));
    aikaArray2[2] = (testaaAika(eka,toka));
    aikaArray2[3] = ( testaaAika(eka,toka));
    System.out.println("kolmen false ajon tulos keskiarvona : " + (aikaArray[1] + aikaArray[2]+ aikaArray[3]) / 3);
    System.out.println("kolmen true ajon tulos keskiarvona : " + (aikaArray2[1] + aikaArray2[2]+ aikaArray2[3]) / 3);
   

}

}
